<div class="container">

    <div class="row">
        <div class="col-md-12" style="font-size:20px;">
            <h2>关于项目</h2>
            <br>
            <p>这是一个开源的网址导航网站项目，您可以拿来制作自己的网址导航，也可以做与导航无关的网站。</p>
            <p>网站前台静态页面采用 <a href="http://viggoz.com/" target="_blank">viggoz</a> 的 <a href="https://github.com/WebStackPage/WebStackPage.github.io">WebStack</a>
                项目源码。</p>
            <p>如果对本项目有任何建议都可以发起 issue。</p>
        </div>
    </div>

    <br>

    <div class="row">
            <div class="col-md-12" style="font-size:20px;">
                <h2>关于作者</h2>
                <br>
                <p>GitHub 地址：<a href="https://github.com/hui-ho">请看</a></p>
                <p>E-mail 地址：hui-ho@outlook.com</p>
                <p>如果你有更好的想法，可以通过邮件与我联系，欢迎与我交流分享。</p>
            </div>
        </div>
</div>