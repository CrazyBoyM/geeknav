<!DOCTYPE html>
<html lang="zh">

@include('layouts.header')
<body>
	<!-- Main container -->
	<div class="container">
		<!-- Blueprint header -->
		<header class="bp-header cf">
			<div class="dummy-logo">
				<img src="img/logo.png" width="286px" height="87px"/>
				<!--<div class="dummy-icon foodicon foodicon--coconut"></div>-->
				<!--<h1 class="dummy-heading">Air Nav</h1>-->
			</div>
			<div class="bp-header__main">
				<span class="bp-header__present">极客导航 <span class="bp-tooltip bp-icon bp-icon--about" data-content="Geek Navigation is a tool website.Here are some excellent websites related to programming, design and learning,and you can also find some online tools conveniently."></span></span>
				<h1 class="bp-header__title">Hello,world!</h1>
				<nav class="bp-nav">
					<a class="bp-nav__item bp-icon bp-icon--prev" href="http://tympanus.net/Blueprints/PageStackNavigation/" data-info="previous Blueprint"><span>Previous Blueprint</span></a>
					<!--a class="bp-nav__item bp-icon bp-icon--next" href="" data-info="next Blueprint"><span>Next Blueprint</span></a-->
					<a class="bp-nav__item bp-icon bp-icon--drop" href="http://tympanus.net/codrops/?p=25521" data-info="back to the Codrops article"><span>back to the Codrops article</span></a>
					<a class="bp-nav__item bp-icon bp-icon--archive" href="http://tympanus.net/codrops/category/blueprints/" data-info="Blueprints archive"><span>Go to the archive</span></a>
				</nav>
			</div>
		</header>
		<button class="action action--open" aria-label="Open Menu"><span class="icon icon--menu"></span></button>
        @include('layouts.sidebar')

        <div class="main-content">
            <!--<nav class="navbar user-info-navbar" role="navigation">-->
                <!-- User Info, Notifications and Menu Bar -->
                <!-- Left links for user info navbar -->
                <!--<ul class="user-info-menu left-links list-inline list-unstyled">-->
                <!--    <li class="hidden-sm hidden-xs">-->
                <!--        <a href="#" data-toggle="sidebar">-->
                <!--            <i class="fa-bars"></i>-->
                <!--        </a>-->
                <!--    </li>-->
                <!--</ul>-->
               
            <!--</nav>-->

            @include('layouts.content')

            @include('layouts.footer')
</body>

</html>
<!--        </div>-->
<!--    </div>-->
    <!-- 锚点平滑移动 -->
<!--    <script type="text/javascript">-->
<!--    $(document).ready(function() {-->
<!--        $(document).on('click', '.has-sub', function(){-->
<!--            var _this = $(this)-->
<!--            if(!$(this).hasClass('expanded')) {-->
<!--               setTimeout(function(){-->
<!--                    _this.find('ul').attr("style","")-->
<!--               }, 300);-->
              
<!--            } else {-->
<!--                $('.has-sub ul').each(function(id,ele){-->
<!--                    var _that = $(this)-->
<!--                    if(_this.find('ul')[0] != ele) {-->
<!--                        setTimeout(function(){-->
<!--                            _that.attr("style","")-->
<!--                        }, 300);-->
<!--                    }-->
<!--                })-->
<!--            }-->
<!--        })-->
<!--        $('.user-info-menu .hidden-sm').click(function(){-->
<!--            if($('.sidebar-menu').hasClass('collapsed')) {-->
<!--                $('.has-sub.expanded > ul').attr("style","")-->
<!--            } else {-->
<!--                $('.has-sub.expanded > ul').show()-->
<!--            }-->
<!--        })-->
<!--        $("#main-menu li ul li").click(function() {-->
            <!--$(this).siblings('li').removeClass('active'); // 删除其他兄弟元素的样式-->
            <!--$(this).addClass('active'); // 添加当前元素的样式-->
<!--        });-->
<!--        $("a.smooth").click(function(ev) {-->
<!--            ev.preventDefault();-->

<!--            public_vars.$mainMenu.add(public_vars.$sidebarProfile).toggleClass('mobile-is-visible');-->
<!--            ps_destroy();-->
<!--            $("html, body").animate({-->
<!--                scrollTop: $($(this).attr("href")).offset().top - 30-->
<!--            }, {-->
<!--                duration: 500,-->
<!--                easing: "swing"-->
<!--            });-->
<!--        });-->
<!--        return false;-->
<!--    });-->

<!--    var href = "";-->
<!--    var pos = 0;-->
<!--    $("a.smooth").click(function(e) {-->
<!--        $("#main-menu li").each(function() {-->
<!--            $(this).removeClass("active");-->
<!--        });-->
<!--        $(this).parent("li").addClass("active");-->
<!--        e.preventDefault();-->
<!--        href = $(this).attr("href");-->
<!--        pos = $(href).position().top - 30;-->
<!--    });-->
<!--    </script>-->
<!--</body>-->

<!--</html>-->
