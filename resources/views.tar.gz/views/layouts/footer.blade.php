<!-- Main Footer -->
<!-- Choose between footer styles: "footer-type-1" or "footer-type-2" -->
<!-- Add class "sticky" to  always stick the footer to the end of page (if page contents is small) -->
<!-- Or class "fixed" to  always fix the footer to the end of page -->
<!--<footer class="main-footer sticky footer-type-1">-->
<!--    <div class="footer-inner">-->
        <!-- Add your copyright text here -->
<!--        <div class="footer-text">-->
<!--            &copy; {{ date('Y') }}-->
<!--            <a href="/">-->
<!--                <strong>{{ env('APP_NAME') }}</strong>-->
<!--            </a> -->
<!--            <a href="https://github.com/CrazyBoyM/WebStack-Laravel" target="_blank">-->
<!--                <strong>Github</strong>-->
<!--            </a>-->
<!--            <span>{{ config('icp_record') }}</span>-->
            <!--  - Purchase for only <strong>23$</strong> -->
<!--        </div>-->
        <!-- Go to Top Link, just add rel="go-top" to any link to add this functionality -->
<!--        <div class="go-up">-->
<!--            <a href="#" rel="go-top">-->
<!--                <i class="fa-angle-up"></i>-->
<!--            </a>-->
<!--        </div>-->
<!--    </div>-->
<!--<script>-->
<!--  ((window.gitter = {}).chat = {}).options = {-->
   
<!--    room: 'GeekS356/GeekNav'-->
<!--  };-->
<!--</script>-->
<!--<script src="https://cdn.bootcss.com/gitter-sidecar/1.3.3/sidecar.js" async defer></script>-->

<!--</footer>-->
	<script src="js/classie.js"></script>
	<script src="js/dummydata.js"></script>
	<script src="js/main.js"></script>
	<script>
	(function() {
		var menuEl = document.getElementById('ml-menu'),
			mlmenu = new MLMenu(menuEl, {
				// breadcrumbsCtrl : true, // show breadcrumbs
				// initialBreadcrumb : 'all', // initial breadcrumb text
				backCtrl : false, // show back button
				// itemsDelayInterval : 60, // delay between each menu item sliding animation
				onItemClick: loadDummyData // callback: item that doesn´t have a submenu gets clicked - onItemClick([event], [inner HTML of the clicked item])
			});

		// mobile menu toggle
		var openMenuCtrl = document.querySelector('.action--open'),
			closeMenuCtrl = document.querySelector('.action--close');

		openMenuCtrl.addEventListener('click', openMenu);
		closeMenuCtrl.addEventListener('click', closeMenu);

		function openMenu() {
			classie.add(menuEl, 'menu--open');
		}

		function closeMenu() {
			classie.remove(menuEl, 'menu--open');
		}

		// simulate grid content loading
		var gridWrapper = document.querySelector('.content');

		function loadDummyData(ev, itemName) {
			ev.preventDefault();

			closeMenu();
			gridWrapper.innerHTML = '';
			classie.add(gridWrapper, 'content--loading');
			setTimeout(function() {
				classie.remove(gridWrapper, 'content--loading');
				gridWrapper.innerHTML = '<ul class="products">' + dummyData[itemName] + '<ul>';
			}, 700);
		}
	})();
	</script>

