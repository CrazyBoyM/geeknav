@php
	$root=array();
	foreach ($categories as $categorie):
		if ($categorie->children_count != 0 && $categorie->parent_id == 0):
			$root[] = $categorie;
		endif;
	endforeach;
@endphp
<nav id="ml-menu" class="menu">
			<button class="action action--close" aria-label="Close Menu"><span class="icon icon--cross"></span></button>
			<div class="menu__wrap">
			<ul data-menu="main" class="menu__level">
				
			@foreach ($root as $item)
			<li class="menu__item">
				@if ($$fa->children_count != 0)
			<a class="menu__link" data-submenu="submenu-{{ $$item->id }}" href="#">{{ $$item->title }}</a>
				@else
			<a class="menu__link" href="#">{{ $$item->title }}</a>
			</li>
				@endif
			@endforeach
			</ul>
			
			@foreach ($root as $fa)
			<ul data-menu="submenu-{{{$$fa-id}}" class="menu__level">
				@foreach ($$fa->children as $child)
					@if ($child->children_count == 0)
				<li class="menu__item"><a class="menu__link" href="#">{{$child->title}}</a></li>
					@else
				<li class="menu__item"><a class="menu__link" data-submenu="submenu-{{$child->id}}" href="#">{{$child->title}}</a></li>
					@endif
				@endforeach
			</ul>
			@foreach

			@foreach ($root as $fa)
					@foreach ($$fa->children as $child)
						@if ($child->children_count != 0)
			<ul data-menu="submenu-{{$child->id}}" class="menu__level">
							@foreach ($child->children as $child2)
				<li class="menu__item"><a class="menu__link" href="#">{{$child2->title}}</a></li>
							@endforeach
			</ul>
						@endif
					@endforeach
			@endforeach
			</div>
</nav>

        <!--<ul id="main-menu" class="menu__level">-->
        <!--    @foreach ($categories as $categorie)-->
        <!--        <li>-->
        <!--            @if ($categorie->children_count == 0 && $categorie->parent_id == 0)-->
                    
        <!--                <a href="#{{ $categorie->title }}" class="menu__link">-->
        <!--                    <i class="fa fa-fw {{ $categorie->icon }}"></i>-->
        <!--                    <span class="title">{{ $categorie->title }}</span>-->
        <!--                </a>-->
                     
        <!--            @elseif ($categorie->children_count != 0 && $categorie->parent_id == 0)-->
                    
<!--                        <a>-->
<!--                            <i class="fa fa-fw {{ $categorie->icon }}"></i>-->
<!--                            <span class="title">{{ $categorie->title }}</span>-->
<!--                        </a>-->
<!--                        <ul>-->
<!--                            @foreach ($categorie->children as $child)-->
<!--                                <li>-->
<!--                                    <a href="#{{ $child->title }}" class="smooth">-->
<!--                                        <span class="title">{{ $child->title }}</span>-->
<!--                                    </a>-->
<!--                                </li>-->
<!--                            @endforeach-->
<!--                        </ul>-->
                     
<!--                    @endif-->
<!--                </li>  -->
<!--            @endforeach-->

            <!--<div class="submit-tag">-->
<!--            <li>-->
<!--                <a href="/about">-->
<!--                    <i class="linecons-heart"></i>-->
<!--                    <span class="title">关于本站</span>-->
<!--                </a>-->
<!--            </li>-->
<!--        </ul>-->
<!--    </div>-->
<!--</div>-->
