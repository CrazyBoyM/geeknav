  var __Ox1467e = ["checked", "input[name=\"type\"][value=\"", "\"]", "querySelector", "length", "s-current",
                        "remove", "classList", "add", "parentNode", "superSearch", "setItem", "localStorage", "getItem", "target", "value",
                        "type", "focus", "newWindow", "preventDefault", "", "action", "open", "href", "input[name=\"type\"]:checked",
                        "data-placeholder", "getAttribute", "placeholder", "setAttribute", "_blank", "removeAttribute",
                        "input[name=\"type\"]", "querySelectorAll", "#super-search-fm", "#search-text", "#set-search-blank",
                        ".search-group", "change", "addEventListener", "submit"
                ];             
  !function(){function _0x3bccx1(){_0x3bccx2(),_0x3bccx3(),_0x3bccx5(),_0x3bccx6()}function _0x3bccx2(){_0x3bccx17[__Ox1467e[0]]= _0x3bccxf()}function _0x3bccx3(){var _0x3bccx4=document[__Ox1467e[3]](__Ox1467e[1]+ _0x3bccxc()+ __Ox1467e[2]);_0x3bccx4&& (_0x3bccx4[__Ox1467e[0]]= !0,_0x3bccx7(_0x3bccx4))}function _0x3bccx5(){_0x3bccx12(_0x3bccx11())}function _0x3bccx6(){_0x3bccx13(_0x3bccx10())}function _0x3bccx7(_0x3bccx4){for(var _0x3bccx8=0;_0x3bccx8< _0x3bccx18[__Ox1467e[4]];_0x3bccx8++){_0x3bccx18[_0x3bccx8][__Ox1467e[7]][__Ox1467e[6]](__Ox1467e[5])};_0x3bccx4[__Ox1467e[9]][__Ox1467e[9]][__Ox1467e[9]][__Ox1467e[7]][__Ox1467e[8]](__Ox1467e[5])}function _0x3bccx9(_0x3bccx4,_0x3bccx8){window[__Ox1467e[12]][__Ox1467e[11]](__Ox1467e[10]+ _0x3bccx4,_0x3bccx8)}function _0x3bccxa(_0x3bccx4){return window[__Ox1467e[12]][__Ox1467e[13]](__Ox1467e[10]+ _0x3bccx4)}function _0x3bccxb(_0x3bccx4){_0x3bccx19= _0x3bccx4[__Ox1467e[14]],_0x3bccx12(_0x3bccx11()),_0x3bccx13(_0x3bccx4[__Ox1467e[14]][__Ox1467e[15]]),_0x3bccx9(__Ox1467e[16],_0x3bccx4[__Ox1467e[14]][__Ox1467e[15]]),_0x3bccx16[__Ox1467e[17]](),_0x3bccx7(_0x3bccx4[__Ox1467e[14]])}function _0x3bccxc(){var _0x3bccx8=_0x3bccxa(__Ox1467e[16]);return _0x3bccx8|| _0x3bccx4[0][__Ox1467e[15]]}function _0x3bccxd(_0x3bccx4){_0x3bccx9(__Ox1467e[18],_0x3bccx4[__Ox1467e[14]][__Ox1467e[0]]?1:-1),_0x3bccx14(_0x3bccx4[__Ox1467e[14]][__Ox1467e[0]])}function _0x3bccxe(_0x3bccx4){return _0x3bccx4[__Ox1467e[19]](),__Ox1467e[20]== _0x3bccx16[__Ox1467e[15]]?(_0x3bccx16[__Ox1467e[17]](),!1):(_0x3bccx13(_0x3bccx10()+ _0x3bccx16[__Ox1467e[15]]),_0x3bccx14(_0x3bccxf()),_0x3bccxf()?window[__Ox1467e[22]](_0x3bccx8[__Ox1467e[21]],+ new Date):location[__Ox1467e[23]]= _0x3bccx8[__Ox1467e[21]],void(0))}function _0x3bccxf(){var _0x3bccx4=_0x3bccxa(__Ox1467e[18]);return _0x3bccx4?1== _0x3bccx4:!0}function _0x3bccx10(){return document[__Ox1467e[3]](__Ox1467e[24])[__Ox1467e[15]]}function _0x3bccx11(){return document[__Ox1467e[3]](__Ox1467e[24])[__Ox1467e[26]](__Ox1467e[25])}function _0x3bccx12(_0x3bccx4){_0x3bccx16[__Ox1467e[28]](__Ox1467e[27],_0x3bccx4)}function _0x3bccx13(_0x3bccx4){_0x3bccx8[__Ox1467e[21]]= _0x3bccx4}function _0x3bccx14(_0x3bccx4){_0x3bccx4?_0x3bccx8[__Ox1467e[14]]= __Ox1467e[29]:_0x3bccx8[__Ox1467e[30]](__Ox1467e[14])}var _0x3bccx15,_0x3bccx4=document[__Ox1467e[32]](__Ox1467e[31]),_0x3bccx8=document[__Ox1467e[3]](__Ox1467e[33]),_0x3bccx16=document[__Ox1467e[3]](__Ox1467e[34]),_0x3bccx17=document[__Ox1467e[3]](__Ox1467e[35]),_0x3bccx18=document[__Ox1467e[32]](__Ox1467e[36]),_0x3bccx19=_0x3bccx4[0];for(_0x3bccx1(),_0x3bccx15= 0;_0x3bccx15< _0x3bccx4[__Ox1467e[4]];_0x3bccx15++){_0x3bccx4[_0x3bccx15][__Ox1467e[38]](__Ox1467e[37],_0x3bccxb)};_0x3bccx17[__Ox1467e[38]](__Ox1467e[37],_0x3bccxd),_0x3bccx8[__Ox1467e[38]](__Ox1467e[39],_0x3bccxe)}()
  
  
  
  
  	var ongeek = true;
	function geekdiv(){
		if(ongeek){
			document.getElementById("geek").style.display="none";
			document.getElementById("geek2").style.display="block";
			ongeek = false;
			}
	}
	var html="<center><img style='height: 110px;width: 110px;padding-top:6px;' src='img/qr.jpg'></center><center>极客导航第四代</center><center>安全，快速，无痕</center><center>Ctrl + D 收藏 </center><center>->版权所有,抄袭必究<-</center>";
	function qrcode(){
		tip(html,'about',17000,3);
	}
	function back(){
		if(!ongeek){
		document.getElementById("geek2").style.display="none";
		document.getElementById("geek").style.display="block";
		ongeek = true;
		}
	}
	var onmenu=false;
	//var ssr=true;
	function opengeek(){
		if(!onmenu){
		// document.getElementById("geekbutton").style.display="none";
		// document.getElementById("geektitle").style.display="none";
		//$("#content").css({"background":"#2a2b30"});
		// if(ssr){
		// var ss="<br><br><br><span style=\"color:rgba(255,255,255,.5);\">Copyright © 2020.Crafted with<a href=\"https://github.com/CrazyBoyM/geeknav\">GeekNav</a>.</span>";
		// document.getElementById("geektext").innerHTML+=ss;
		// ssr=false;
		// }
		document.getElementById("geek").style.margin="0 0 0 300px";
		document.getElementById("geek2").style.margin="0 0 0 300px";
		document.getElementById("gk").style.margin="0 0 0 300px";
		// document.getElementById("gk").innerHTML='<span class="icon icon--cross"></span>';
		document.getElementById("geeklogo").style.display="flex";
		document.getElementById("ml-menu").style.display="block";
		onmenu=true;
		}else{
		document.getElementById("geek").style.margin="0 0 0 0";
		document.getElementById("geek2").style.margin="0 0 0 0";
		document.getElementById("gk").style.margin="0 0 0 0";
		document.getElementById("geeklogo").style.display="none";
		document.getElementById("ml-menu").style.display="none";
		// document.getElementById("gk").innerHTML='<span class="icon icon--menu"></span>';
		back();
		onmenu=false;
		}
		
	}
	var minx=false;
	function openx(id,name,url,size){
	geekw=layer.open({
		  id: id,
		  fixed: false,
	      type: 2,
	      title: name,
	      shadeClose: true,
	      offset: 'rb',
	      shade: false,
	      maxmin: true, //开启最大化最小化按钮
	      content: url,
	      area: size,
	      resize: true,
	      skin: 'layui-layer-lan',
	      min: function(){
			$('.layui-layer').css({
				'top': 'auto',
				'left': 'auto',
				'bottom': '0',
				'right': '0'
				});
			minx=true;
			},
		  cancle:function(){
		  	minx=false;
		    }
	    });
	}
	function musicx(id,name,url,size){
			if(minx){
				layer.restore(geekw);
				minx=false;
			}else{
				openx(id,name,url,size);
				// tip('窗口会直接在内部打开第三方音乐网站,内容并非本站提供','geeknav',3800,2);
				minx=false;
			}
	}
	var minx2=false;
	function openx2(id,name,url,size){
	geekw2=layer.open({
		  id: id,
		  fixed: false,
	      type: 2,
	      title: name,
	      shadeClose: true,
	      offset: 'rb',
	      shade: false,
	      maxmin: true, //开启最大化最小化按钮
	      content: url,
	      area: size,
	      resize: true,
	      skin: 'layui-layer-lan',
	      min: function(){
			$('.layui-layer').css({
				'top': 'auto',
				'left': 'auto',
				'bottom': '0',
				'right': '0'
				});
			minx2=true;
			},
		  cancle:function(){
		  	minx2=false;
		    }
	    });
	}
	function codex(id,name,url,size){
			if(minx2){
				layer.restore(geekw2);
				minx2=false;
			}else{
				openx2(id,name,url,size);
				// tip('窗口会直接在内部打开第三方ide网站,内容并非本站提供','geeknav',3800,2);
				minx2=false;
			}
	}
	$("div").on("mouseover","i",function(){
		var id=this.id;
		var s=$("#"+id).attr("data-d");
		tip(s, id,2000,2);
		}).on('mouseleave', 'i', function(){tipx(i);});
	(function(){layer.open({
	content: '浏览器滚动条已锁',
	scrollbar: false
	});});

	//opengeek();
	
	 $(document).bind("contextmenu", function () { return false; });//禁止右键
		        document.oncontextmenu = function () { return false; };
		        document.onkeydown = function () {
		            if (window.event && window.event.keyCode == 123) {
		                event.keyCode = 0;
		                event.returnValue = false;
		                return false;
		            }
		        };//禁止F12
		        
	var _hmt = _hmt || [];
	(function() {
	var hm = document.createElement("script");
	hm.src = "https://hm.baidu.com/hm.js?0815ca0ab4a5299677d0f428b281ffa1";
	var s = document.getElementsByTagName("script")[0]; 
	s.parentNode.insertBefore(hm, s);
	})();